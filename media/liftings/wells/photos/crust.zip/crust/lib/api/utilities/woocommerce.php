<?php
/**
 * @author WinsomeThemes
 * @license Commercial License
 * @link http://www.winsomethemes.com
 */

add_theme_support('wc-product-gallery-zoom');
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support('wc-product-gallery-slider');
add_theme_support( 'woocommerce', [
    'single_image_width'    => '',
    'product_grid'          => [
        'default_rows'    => 3,
        'min_rows'        => 2,
        'max_rows'        => 8,
        'default_columns' => 3,
        'min_columns'     => 2,
        'max_columns'     => 5,
    ],
]);

add_action( 'init', 'crust_woo_actions', 20 );
function crust_woo_actions()
{

	$listing = crust_woo_settings()['style'];
	$quick = crust_mod( 'woo_display_quick', '1' );

    // Remove Some Default Woos
    remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar' );
	add_filter( 'woocommerce_show_page_title', '__return_false' );
	add_action('crust_after_footer', 'add_footer_q_view');
	add_action("wp_ajax_crust_q_view_popup", "crust_q_view_popup");
	add_action("wp_ajax_nopriv_crust_q_view_popup", "crust_q_view_popup");

	remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
	remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash' );
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail' );
	remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price');
	remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
	remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
	remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title');

	// Add Actions
    add_action( 'woocommerce_product_meta_end', 'crust_social_share_product', 10, 2 );
	add_filter( "woocommerce_loop_add_to_cart_link", "crust_add_to_cart_markup", 10, 3 );

	// Loop
	add_action( 'woocommerce_before_shop_loop_item', 'crust_before_loop_item' );
	add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_show_product_loop_sale_flash' );

	switch ( $listing ){
        case 'card':

	        crust_loop_title();
	        crust_loop_image_after();
	        add_action( 'woocommerce_after_shop_loop_item', 'crust_add_loop_description' );
	        crust_loop_price_start();
	        add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_price' );
	        add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_rating' );
	        crust_loop_close_after();
	        crust_loop_bottom();
            break;

		case 'minimal':

			crust_loop_image();
			crust_loop_title_after();
			add_action( 'woocommerce_after_shop_loop_item', 'crust_add_loop_description' );
			add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_price' );
			crust_loop_price_start();
			add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_rating' );
			add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
			crust_loop_close_after();
			crust_loop_bottom();
			break;

		case 'over':

			crust_loop_image();
			crust_loop_over_start();
			crust_loop_title_after();
			add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_rating' );
			crust_over_bottom();
			crust_loop_close_after();
			break;

		default:

			crust_loop_image();
			crust_loop_title_after();
			crust_loop_price_start();
			add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_price' );
			add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_rating' );
			crust_loop_close_after();
			add_action( 'woocommerce_after_shop_loop_item', 'crust_add_loop_description' );
			crust_loop_bottom();
		    break;

    }

	add_action( 'woocommerce_after_shop_loop_item', 'crust_wrap_close_markup' );

	// Add Filters
	if( crust_mod('woo_sale_replace', true ) === true ) {
		add_filter( 'woocommerce_sale_flash', 'crust_replace_sale_text' );
	}

}

function crust_loop_bottom(){
	$quick = crust_mod( 'woo_display_quick', '1' );
	$love = crust_mod( 'woo_display_love', '1' );

	if( $quick === true || $love === true ){
		add_action( 'woocommerce_after_shop_loop_item', 'crust_bottom_loop_tools' );
		if( $quick === true ){
			add_action( 'woocommerce_after_shop_loop_item', 'crust_quick_view_button' );
		}
		if( $love === true ) {
			add_action( 'woocommerce_after_shop_loop_item', 'crust_wishlist_button' );
		}
		crust_loop_close_after();
	}
}

function crust_loop_bottom_before(){
	$quick = crust_mod( 'woo_display_quick', '1' );
	$love = crust_mod( 'woo_display_love', '1' );

	if( $quick === true || $love === true ){
		add_action( 'woocommerce_before_shop_loop_item', function (){
			echo '<div class="crust-woo-loop-bottom">';
		});
		if( $quick === true ){
			add_action( 'woocommerce_before_shop_loop_item', 'crust_quick_view_button' );
		}
		if( $love === true ) {
			add_action( 'woocommerce_before_shop_loop_item', 'crust_wishlist_button' );
		}
		add_action( 'woocommerce_before_shop_loop_item', function (){
			echo '</div>';
		});
	}
}

function crust_add_to_cart_markup ( $html, $product, $args ) {

	$listing = crust_woo_settings()['style'];

	switch ($listing){
        case 'minimal':
	        $basket = '<i class="fad fa-shopping-bag"></i>';
            break;
		case 'over':
			$basket = '<i class="fal fa-shopping-bag"></i>';
			break;
		case 'card':
			$basket = '<i class="fad fa-shopping-cart"></i>';
			break;
        default:
	        $basket = '<i class="fad fa-shopping-basket"></i>';
	        break;
    }

    $html = sprintf( '<a href="%s" data-quantity="%s" class="%s" %s>%s</a>',
        esc_url( $product->add_to_cart_url() ),
        esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
        esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
        isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
        '<span class="crust-tooltip" data-title="'.esc_attr( $product->add_to_cart_text() ).'">'.$basket.'</span>'
    );
	return $html;

}

function crust_loop_image(){

    $listing = crust_woo_settings()['style'];
	add_action( 'woocommerce_before_shop_loop_item', 'crust_before_loop_item_image' );
	add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open' );
	add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_thumbnail' );
	add_action( 'woocommerce_before_shop_loop_item', 'crust_second_product_thumbnail' );
	add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_close' );

	if( $listing !== 'minimal' ){
	    add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
    }

	if( $listing === 'over' ){
		crust_loop_bottom_before();
		add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_price' );
    }

	add_action( 'woocommerce_before_shop_loop_item', 'crust_wrap_close_markup' );
}

function crust_loop_image_after(){

	$listing = crust_woo_settings()['style'];
	add_action( 'woocommerce_after_shop_loop_item', 'crust_before_loop_item_image' );
	add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_open' );
	add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_thumbnail' );
	add_action( 'woocommerce_after_shop_loop_item', 'crust_second_product_thumbnail' );
	add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close' );

	if( $listing !== 'minimal' ){
		add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
	}

	crust_loop_close_after();
}

function crust_loop_title(){
	add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open' );
	add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_title' );
	add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_close' );
}

function crust_loop_title_after(){
	add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_open' );
	add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_title' );
	add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close' );
}

function crust_over_bottom(){
	add_action( 'woocommerce_after_shop_loop_item', function (){
	    global $product;
	    $url = $product->get_permalink();
		echo '<a href="'.esc_url($url).'" class="crust-woo-price-wrap primary-bg"><i class="fad fa-chevron-right"></i></a>';
	});
}

function crust_before_loop_item_image(){
	$class = 'crust-product-img-wrap';
	echo '<div class="'. esc_attr($class) .'">';
}

function crust_loop_over_start(){
	add_action( 'woocommerce_after_shop_loop_item', function () {
		$class = 'crust-product-over-bottom';
		echo '<div class="' . esc_attr( $class ) . '">';
	});
}

function crust_before_loop_item(){
	$class = 'crust-products-wrap';
	echo '<div class="'. esc_attr($class) .'">';
}

function crust_loop_price_start(){
	add_action( 'woocommerce_after_shop_loop_item', function (){
		echo '<div class="crust-woo-price-wrap">';
	});
}

function crust_loop_close_after(){
	add_action( 'woocommerce_after_shop_loop_item', function (){
		echo '</div>';
	});
}

function crust_bottom_loop_tools(){
	echo '<div class="crust-woo-loop-bottom">';
}

function crust_wrap_close_markup(){
	echo '</div>';
}

function crust_add_loop_description() {
	global $product;
	$desc = crust_mod('woo_display_desc', '1');
	if( $desc === true ){
		echo '<div class="crust-short-desc-loop">';
		echo apply_filters( 'woocommerce_short_description', $product->get_short_description() );
		echo '</div>';
    }
}

function crust_replace_sale_text($text) {
	global $product;
	$stock         = $product->get_stock_status();
	$product_type  = $product->get_type();
	$sale_price    = 0;
	$regular_price = 0;
    if ( $product_type == 'variable' ) {
        $product_variations = $product->get_available_variations();
        foreach ( $product_variations as $kay => $value ) {
            if ( $value['display_price'] < $value['display_regular_price'] ) {
                $sale_price    = $value['display_price'];
                $regular_price = $value['display_regular_price'];
            }
        }
        if ( $regular_price > $sale_price && $stock != 'outofstock' ) {
            $product_sale = intval( ( ( intval( $regular_price ) - intval( $sale_price ) ) / intval( $regular_price ) ) * 100 );
            if ( $product_sale > 5 ) {
                return '<span class="onsale"><span class="sale-icon" aria-hidden="true"></span> ' . $product_sale . '% OFF</span>';
            }
            if ( $product_sale <= 5 ) {
                return '<span class="onsale"><span class="sale-icon" aria-hidden="true"></span>Sale!</span>';
            }
        } else {
            return '';
        }
    } else {
        $regular_price = get_post_meta( get_the_ID(), '_regular_price', true );
        $sale_price    = get_post_meta( get_the_ID(), '_sale_price', true );
        if ( $regular_price > 5 ) {
            $product_sale = intval( ( ( intval( $regular_price ) - intval( $sale_price ) ) / intval( $regular_price ) ) * 100 );

            return '<span class="onsale"><span class="sale-icon" aria-hidden="true"></span>-' . $product_sale . '%</span>';
        }
        if ( $regular_price >= 0 && $regular_price <= 5 ) {
            $product_sale = ( $sale_price ) ? intval( ( ( intval( $regular_price ) - intval( $sale_price ) ) / intval( $regular_price ) ) * 100 ) : '';

            return '<span class="onsale"><span class="sale-icon" aria-hidden="true"></span>Sale!</span>';
        } else {
            return '';
        }
    }
}

function crust_social_share_product(){
	do_action( 'crust_single_share' );
}

function crust_woocommerce_product_class( $classes, $product ) {
	if ( ! is_product() ) return $classes;
	$shad = ( crust_woo_settings()['shadow'] == 1 ) ? 'crust-gallery-shadow' : '';
	$classes[] = $shad;

	return $classes;
}
add_filter( 'woocommerce_post_class', 'crust_woocommerce_product_class', 10, 2 );

function crust_wc_single_product(){
	$product_cats = wp_get_post_terms( get_the_ID(), 'product_cat' );
	if ( $product_cats && ! is_wp_error ( $product_cats ) ){
		$single_cat = array_shift( $product_cats );
        echo '<div class="crust-pro-cat-block"><a href="'. esc_url( get_term_link($single_cat) ).'">' . $single_cat->name .'</a></div>';
	}
}
add_action( 'woocommerce_single_product_summary', 'crust_wc_single_product', 2 );

function crust_woo_before_login() {
	echo '<span class="hidden crust-hide-login-title"></span>';
}
add_action( 'woocommerce_before_customer_login_form', 'crust_woo_before_login', 10, 0 );

function crust_woo_login_start() {
	echo '<i class="crust-login-icon fad fa-user primary-color"></i><h5 class="crust-login-heading">'. esc_html__( 'Login', 'crust' ) .'</h5>';
}
add_action( 'woocommerce_login_form_start', 'crust_woo_login_start' );

add_filter( 'woocommerce_cart_item_name', 'crust_shipping_class', 20, 3);
function crust_shipping_class( $item_name, $cart_item, $cart_item_key ) {
	if( ! ( is_cart() || is_checkout() ) ) return $item_name;
	$product = $cart_item['data'];
	$shipping_class_id = $product->get_shipping_class_id();
	$shipping_class_term = get_term( $shipping_class_id, 'product_shipping_class' );
	if( empty( $shipping_class_id ) )
		return $item_name;
	return $item_name . '<p class="crust-shipping-class primary-color">'. $shipping_class_term->name . '</p>';
}

add_filter( 'woocommerce_single_product_summary', 'crust_shipping_title_class', 6);
function crust_shipping_title_class() {
	global $product;
	$shipping_class_id = $product->get_shipping_class_id();
	$shipping_class_term = get_term( $shipping_class_id, 'product_shipping_class' );

	$ship_class = ( $shipping_class_id ) ? $shipping_class_term->name : '';

	if( ! $ship_class )
	    return;
	echo '<p class="crust-shipping-class primary-color">'. $ship_class . '</p>';
}

// Cart box markup
add_action('crust_render_cart_box', 'crust_cart_box_markup');
function crust_cart_box_markup()
{

    echo '<a class="crust-close-wrap" href="#"><i class="fad fa-times"></i></a>';
    echo '<div class="crust-mini-cart">';
        echo '<h5 class="crust-cart-head">'. esc_html__('Your Cart', 'crust') .'</h5>';
	    woocommerce_mini_cart();
    echo '</div>';

}

add_action( 'woocommerce_before_main_content', 'crust_woo_wrapper_start', 5 );
add_action( 'woocommerce_after_main_content',  'crust_woo_wrapper_end',   9999 );
add_action( 'crust_add_woo_sidebar',           'crust_woo_sidebar' );

function crust_woo_sidebar()
{
	$sidebar = crust_woo_settings()['bar'];
	$woo_bar = crust_woo_settings()['woo_bar'];

    if( $sidebar === 'none' || $sidebar === '' ) {
        return;
    }

	$bar_class = 'crust-sidebar crust-woo-sidebar col-lg-4';
	$bar_class .= ( crust_mod( 'sticky_sidebar' ) ) ? ' crust-sticky-sidebar' : '';

    echo '<div class="'.esc_attr($bar_class).'">';
        dynamic_sidebar( $woo_bar );
    echo '</div>';

}

function crust_woo_wrapper_start()
{

	$sidebar    = crust_woo_settings()['bar'];
	$listing    = crust_woo_settings()['style'];
    $class      = 'crust-post-wrapper crust-woo-products';
    $class     .= ( $sidebar === 'none' || $sidebar === '' ) ? ' col-lg-12' : ' col-lg-8';
	$class     .= ( $listing !== '' ) ? ' crust-pro-' . $listing : '';
    $mainclass  = 'crust-content-wrap';
    $mainclass .= ( $sidebar === 'none' || $sidebar === '' ) ? ' crust-nobar' : ' crust-bar-' . $sidebar;

    echo '<div class="'. $mainclass .'">';
        crust_page_title_template();
        echo '<div class="crust-content-container">';
            echo '<div class="container">';
                echo '<div class="row">';
                    echo '<div class="'.$class.'">';

}

function crust_woo_wrapper_end()
{
                    echo '</div>';
	                do_action('crust_add_woo_sidebar');
                echo '</div>';
            echo '</div>';
        echo '</div>';
    echo '</div>';

}

add_filter('woocommerce_add_to_cart_fragments', 'crust_mini_add_to_cart_fragment');
if (!function_exists('crust_mini_add_to_cart_fragment')) {
	function crust_mini_add_to_cart_fragment( $fragments )
	{
		ob_start();
		do_action( 'crust_render_cart_box' );
		$fragments[ 'div.crust-mini-cart' ] = ob_get_clean();
		return $fragments;
	}
}

add_filter('woocommerce_add_to_cart_fragments', 'crust_add_to_cart_fragment');
function crust_add_to_cart_fragment( $fragments )
{

	global $woocommerce;
	ob_start();
	?>
    <b class="cart-num"><?php echo sprintf(_n('%d', '%d', $woocommerce->cart->cart_contents_count, 'crust'), $woocommerce->cart->cart_contents_count);?></b>
	<?php
	$fragments['b.cart-num'] = ob_get_clean();

	return $fragments;

}

// woo shopping cart in header & top bar.
if ( ! function_exists( 'crust_woo_cart' ) ){

    function crust_woo_cart()
    {
        global $woocommerce;
        echo '<a href="#" class="crust-cart-btn">';
            echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 29.72 27.32"><path d="M29.53,4.78a.81.81,0,0,0-.66-.32H8.1A9.36,9.36,0,0,0,1,0,.86.86,0,1,0,.72,1.7H.83c.26,0,6.5.71,6.5,6.71,0,.79,0,1.58,0,2.35v.05c.13,3.77.69,7.21,3,9.49a7.74,7.74,0,0,0,1.67,1.23,3.07,3.07,0,1,0,4.43,1.23c.48,0,1,.06,1.49.06h2.42a3.07,3.07,0,1,0,5.43,0h.46a.86.86,0,0,0,0-1.72H18.57c-3.19.1-5.47-.57-7-2a6.51,6.51,0,0,1-1.36-2h16.2a.87.87,0,0,0,.84-.67L29.7,5.5A.82.82,0,0,0,29.53,4.78ZM13.75,25.47a1.36,1.36,0,1,1,1.35-1.36A1.36,1.36,0,0,1,13.75,25.47Zm9.38.14a1.36,1.36,0,1,1,1.35-1.35h0A1.35,1.35,0,0,1,23.13,25.61ZM27.8,6.17,27,9.94H9.06c0-.5,0-1,0-1.51a9,9,0,0,0-.27-2.26Zm-2,9.24H9.64a19.81,19.81,0,0,1-.53-3.76H26.59Z"/></svg>';
            echo '<b class="cart-num">'. sprintf( _n( '%d', '%d', $woocommerce->cart->cart_contents_count, 'crust' ), $woocommerce->cart->cart_contents_count ) .'</b>';
        echo '</a>';
    }

}

// Display the second thumbnails
function crust_second_product_thumbnail() {
	global $product;
	$attachment_ids = $product->get_gallery_image_ids();
	if ( $attachment_ids ) {
		$secondary_image_id = $attachment_ids['0'];
		echo wp_get_attachment_image( $secondary_image_id, 'shop_catalog', '', $attr = [ 'class' => 'crust-product-alt-img' ] );
	}
}

if ( ! function_exists( 'crust_wishlist_button' ) ) {
	function crust_wishlist_button(){
		if( function_exists( 'YITH_WCWL' ) ){
		    echo do_shortcode( '[yith_wcwl_add_to_wishlist label="" product_added_text="'.esc_attr__('Added to wishlist','crust').'" browse_wishlist_text="'.esc_attr__('View wishlist','crust').'" already_in_wishslist_text="'
                    .esc_attr__('Already in wishlist','crust').'" icon="fal fa-heart"]' );
		}
	}
}
add_action('crust_site_header_wishlist_button','crust_header_wishlist_button_markup');
    function crust_header_wishlist_button_markup(){
        if( function_exists( 'YITH_WCWL' ) ){
            echo '<div class="crust-header-button crust-header-cart">';
                $wishlist_count = YITH_WCWL()->count_products();
                $wishlist_page_id = yith_wcwl_object_id( get_option( 'yith_wcwl_wishlist_page_id' ) );
                $base_url = get_the_permalink( $wishlist_page_id );
                echo '<a href="'. esc_url($base_url) .'"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26.99 24.74"><path d="M20,0c-3,0-5.47,2.78-6.47,4.09C12.49,2.78,10,0,7,0,3.15,0,0,3.57,0,7.94a8.29,8.29,0,0,0,2.61,6.14.47.47,0,0,0,.09.12L13.1,24.57a.56.56,0,0,0,.79,0L24.64,13.83l.11-.11a3.43,3.43,0,0,0,.27-.27.71.71,0,0,0,.1-.14A8.52,8.52,0,0,0,27,7.94C27,3.57,23.83,0,20,0Zm4.22,12.68,0,.06-.16.17L13.49,23.38,3.62,13.53a.55.55,0,0,0-.13-.17A7.17,7.17,0,0,1,1.12,7.94c0-3.76,2.65-6.81,5.9-6.81s6,4.2,6,4.24a.58.58,0,0,0,.81.12A.5.5,0,0,0,14,5.37s2.78-4.24,6-4.24,5.9,3.05,5.9,6.81a7.37,7.37,0,0,1-1.68,4.74Z"/></svg><b class="yith-num">'. $wishlist_count .'</b></a>';
            echo '</div>';
        }
    }


function crust_update_wishlist_count(){
    if( function_exists( 'YITH_WCWL' ) ){
        wp_send_json( YITH_WCWL()->count_products() );
    }
}
add_action( 'wp_ajax_update_wishlist_count', 'crust_update_wishlist_count' );
add_action( 'wp_ajax_nopriv_update_wishlist_count', 'crust_update_wishlist_count' );

if ( ! function_exists( 'crust_get_pro_thumbs' ) ){
	function crust_get_pro_thumbs ($id){
		global $post;
		$product = wc_get_product( $id );
		$main_img = get_post_thumbnail_id( $id );
        $attachment = wp_get_attachment_url( $main_img );
		$attachment_ids = $product->get_gallery_image_ids();
		if ( $attachment_ids || $main_img ) {
			$output     = '';
			$loop       = 0;
			$output .= '<div class="swiper-container crust-q-view-wrap">';
			    $output .= '<div class="swiper-wrapper">';
                    $output .= '<div class="swiper-slide"><a href="'.esc_url($attachment).'" class="crust_pro_zoom"><img src="'.esc_url($attachment).'" class="attachment-shop_full size-shop_full" /></a></div>';
                    if ( $attachment_ids ) {
                        foreach ( $attachment_ids as $attachment_id ) {
                            $image_link = wp_get_attachment_url( $attachment_id );
                            if ( ! $image_link ) {
                                continue;
                            }
                            $image       = wp_get_attachment_image( $attachment_id, apply_filters( 'single_product_small_thumbnail_size', 'shop_full' ) );
                            $output .= apply_filters( 'woocommerce_single_product_image_thumbnail_html', sprintf( '<div class="swiper-slide"><a href="%s" class="crust_pro_zoom">%s</a></div>', $image_link, $image ), $attachment_id, $post->ID, '' );
                            $loop ++;
                        }
                    }
			    $output .= '</div>';
                $output .= '<div class="swiper-pagination"></div>';
			$output .= '</div>';
			return $output;
		}

	}
}

if ( ! function_exists( 'crust_get_pro_price' ) ){
	function crust_get_pro_price ($id){
		$product = wc_get_product( $id );
		$output = '<div class="product-specs price-block">';
		if ( $price_html = $product->get_price_html() ) {
			$output .= '<div class="price-box">';
                $output .= '<span class="product-price primary-color">';
                    $output .= $product->get_price_html();
                    $output .= '<meta property="price" content="'.esc_attr( $product->get_price() ).'" />';
                    $output .= '<meta property="priceCurrency" content="'.get_woocommerce_currency().'" />';
                $output .= '</span>';
			$output .= '</div>';
		} else {
			$output .= '<div class="box error-box">'.esc_html__( 'No Price Added.', 'crust' ).'</div>';
		}
		$output .= '</div>';
		return $output;
	}
}

if ( ! function_exists( 'crust_get_pro_meta' ) ){
	function crust_get_pro_meta ($id){

		$product = wc_get_product( $id );
		$output = '<ul class="crust-quick-meta">';

            if ( wc_product_sku_enabled() && ( $product->get_sku() || $product->is_type( 'variable' ) ) ) {
                $output .= '<li><i class="fad fa-check primary-color"></i><b>'.esc_html__( 'SKU:', 'crust' ).' </b>';
                    $output .= ( $sku = $product->get_sku() ) ? '<span class="sku">' . $sku . '</span>' : '<span class="sku">' . esc_html__( 'N/A', 'crust' ).'</span>';
                $output .= '<li>';
            }
    
            if ( $product->has_weight() ) {
                $output .= '<li>';
                    $output .= '<i class="fad fa-check primary-color"></i><b>'.esc_html__( 'Weight:', 'crust' ).' </b>';
                    $output .= '<span class="product_weight">'.$product->get_weight() . ' ' . esc_attr( get_option( 'woocommerce_weight_unit' ) ).'</span>';
                $output .= '</li>';
            }
            $dimensions = wc_format_dimensions($product->get_dimensions(false));
            if ( $product->has_dimensions() ) {
                $output .= '<li>';
                    $output .= '<i class="fad fa-check primary-color"></i><b>'.esc_html__( 'Dimensions:', 'crust' ).' </b>';
                    $output .= '<span class="product_dimensions">'.$dimensions.'</span>';
                $output .= '</li>';
            }
    
            $output .= wc_get_product_category_list ( $id, ', ', '<li class="posted_in"><i class="fad fa-check primary-color"></i>' . esc_html__( 'Category:', 'crust' ) . ' ', '.</li>' );
    
            $output .= wc_get_product_tag_list( $id, ', ', '<li class="tagged_as"><i class="fad fa-check primary-color"></i>' . esc_html__( 'Tags:', 'crust' ) . ' ', '.</li>' );

		$output .= '</ul>';

		return $output;
	}
}

if ( ! function_exists( 'crust_quick_view_cart_button' ) ){
	function crust_quick_view_cart_button($id) {
		$product = wc_get_product( $id );
		$shop_page_url = get_permalink( wc_get_page_id( 'shop' ) );
		$output = '<div class="crust-pro-block btn-crt">';
		    $output .= '<a rel="nofollow" href="'. esc_url( $shop_page_url.'?add-to-cart='.$product->get_id() ) .'" data-quantity="1" data-product_id="'.esc_attr( $product->get_id() ).'" 
            data-product_sku="" class="btn"><i class="fad fa-shopping-basket"></i>'.esc_html__( 'Add to cart','crust' ).'</a>';
		$output .= '</div>';

		return $output;
	}
}

if ( ! function_exists( 'crust_limit_text' ) ) {
	function crust_limit_text($id, $limit) {
		$product = wc_get_product( $id );
		$txt = ($product->get_short_description()) ? $product->get_short_description() : "";
	    if (str_word_count($txt, 0) > $limit) {
			$words = str_word_count($txt, 2);
			$pos = array_keys($words);
		    $txt = substr($txt, 0, $pos[$limit]) . '...';
		}
		return $txt;
	}
}

if ( ! function_exists( 'crust_product_name' ) ) {
	function crust_product_name($id) {
		$product = wc_get_product( $id );
		return $product->get_name();
	}
}

if ( ! function_exists( 'crust_quick_view_button' ) ){
	function crust_quick_view_button() {
		global $product;
        $id = $product->get_id();
		$nonce = wp_create_nonce("crust_q_view_nonce");
		echo '<a class="crust-quick-view" data-nonce="'.esc_attr($nonce).'" data-id="'. esc_attr($id) .'" href="#" title="'.esc_attr__('Quick View','crust').'"><i class="fad fa-eye"></i></a>';

	}
}

function add_footer_q_view(){
	echo '<div class="crust-woo-quick-view"></div>';
}

function crust_q_view_popup(){

	$id = $_POST['id'];

	echo '<div class="item-content row">';
        echo '<div class="col-lg-6">';
            echo crust_get_pro_thumbs( $id );
        echo '</div>';

        echo '<div class="col-lg-6">';
            echo '<h4 class="crust-pro-block crust-pro-title">'.crust_product_name( $id ).'</h4>';
            echo '<div class="crust-pro-block">';
                echo crust_get_pro_price( $id );
            echo '</div>';
            echo '<div class="crust-pro-block crust-pro-rating"></div>';
            echo '<div class="crust-pro-block">'.crust_limit_text( $id, 20 ).'</div>';
            echo '<div class="crust-pro-block">';
                echo crust_get_pro_meta( $id );
            echo '</div>';
            echo crust_quick_view_cart_button( $id );
        echo '</div>';
    echo '</div>';

    die();
}
