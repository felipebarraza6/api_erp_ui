<?php
/**
 * @author WinsomeThemes
 * @license Commercial License
 * @link http://www.winsomethemes.com
 */

// Page Loader..
add_action( 'wp_body_open', 'crust_page_loader' );
if ( ! function_exists( 'crust_page_loader' ) ) {
	function crust_page_loader()
	{
		$loader   = crust_mod( 'page_loader', '1' );
		$pr_ld    = crust_mod( 'preloaders', 'spin' );
		$loadtxt  = esc_html( crust_mod( 'load_text' ));
		$load_img = wp_get_attachment_url( crust_mod( 'loader_img' ) );
		$f_col = ( crust_mod( 'primary_color' ) === '' ) ? '#ff5b4a' : crust_mod( 'primary_color' );
		$s_col = ( crust_mod( 'secondary_color' ) === '' ) ? '#2f39d3' : crust_mod( 'secondary_color' );

		$class = 'crust-page-loader';
		$class .= ( class_exists('Crust_Core') ) ? ' crust-animated-load' : '';

		if ( $loader ) {
			echo '<div class="'.esc_attr( $class ).'">';
                echo '<div class="crust-inner-loader">';

                    echo '<div class="crust-loader-' . esc_attr( $pr_ld ) . '">';

                        switch ( $pr_ld ){
	                        case '1':
		                        echo '<svg>
										  <g><path d="M 50,100 A 1,1 0 0 1 50,0"/></g>
										  <g><path d="M 50,75 A 1,1 0 0 0 50,-25"/></g>
										  <defs>
										    <linearGradient id="crust-loader-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
										      <stop offset="0%" style="stop-color:'.esc_attr($f_col).'" />
										      <stop offset="100%" style="stop-color:'.esc_attr($s_col).'" />
										    </linearGradient>
										  </defs>
										</svg>';
		                        break;
                            case '2':
                                echo '<svg width="16px" height="12px">
									    <polyline id="crust-loader-back" stroke="'.esc_attr($s_col).'"  points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
									    <polyline id="crust-loader-front" stroke="'.esc_attr($f_col).'" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
									  </svg>';
                                break;

                            case '3':
                                echo '<div class="box">
									        <div></div>
									        <div></div>
									        <div></div>
									        <div></div>
									    </div>
									    <div class="box">
									        <div></div>
									        <div></div>
									        <div></div>
									        <div></div>
									    </div>
									    <div class="box">
									        <div></div>
									        <div></div>
									        <div></div>
									        <div></div>
									    </div>
									    <div class="box">
									        <div></div>
									        <div></div>
									        <div></div>
									        <div></div>
									    </div>';
                                break;

	                        case '4':
	                        	echo '<div class="crust-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';

                            case 'img':
                                if( $load_img ){
                                    echo '<img alt="' . esc_attr__('Loading', 'crust') . '" src="' . esc_url( $load_img ) . '" />';
                                }
                                break;

	                        default:
	                        	break;
                        }

                    echo '</div>';

                    if ( $loadtxt ) {
                        echo '<div class="crust-loader-text">' . esc_html( $loadtxt ) . '</div>';
                    }

                echo '</div>';
			echo '</div>';
		}
	}
}

// Page Main Wrapper Start..
add_action( 'crust_wrapper_start', 'crust_wrapper_start_markup' );
function crust_wrapper_start_markup(){
	$crust_layout = ( crust_meta( 'body_layout' ) === '' ) ? crust_mod( 'body_layout' ) : crust_meta( 'body_layout' );
	$fix_foot     = crust_option( 'fixed_footer', '' );
	$class        = 'crust-main-wrap';
	$class       .= ( $crust_layout == 'boxed' ) ? ' crust-boxed-wrapper' : '';
	$class       .= ( !is_404() && $fix_foot == '1' ) ? ' crust-fix-foot' : '';
	echo '<div id="crust-cursor"><div class="crust-cursor-text"></div><div class="crust-cursor-circle"></div></div>';
	echo '<div class="' . esc_attr( $class ) . '">';
	if( !is_404() && $fix_foot == '1' ){
		echo '<div class="crust-fixed-wrap">';
	}
}


add_action( 'crust_site_header', 'crust_site_head_markup' );
function crust_site_head_markup(){
	?>

	<!DOCTYPE html>
	<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo('charset'); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="https://gmpg.org/xfn/11"/>
		<?php wp_head();
		?>
	</head>
	<body <?php body_class(); ?>>

	<?php
	wp_body_open();
	do_action('splash_screen_template');
	do_action('crust_header_markup');

}

add_action( 'crust_posts_loop', 'crust_posts_loop_markup' );
function crust_posts_loop_markup(){

	while (have_posts()) {
		the_post();
		the_content();

	}

}

add_action( 'crust_index', 'crust_index_markup' );
function crust_index_markup(){

	$post_type = get_post_type();

	if ( is_archive() || is_home() ) {

		if ( class_exists( 'Crust_Core' ) && CRUST_PORTFOLIO === $post_type ) {
			do_action( 'crust_site_portfolio_archive' );
		} else {
			if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'archive' ) ) {
				do_action( 'crust_site_archive' );
			}
		}

	}

}

add_action( 'crust_site_footer', 'crust_site_foot_markup' );
function crust_site_foot_markup(){

        do_action('crust_footer_markup');
        do_action('crust_after_footer');
        wp_footer();
        echo '</body>';
	echo '</html>';

}

add_action( 'crust_site_404', 'crust_site_404_markup' );
function crust_site_404_markup(){
	$logo = wp_get_attachment_url( crust_mod('error404_logo') );

	?>
	<main class="site-main crust-content-wrap">
		<div class="container">
			<div class="row">

				<div class="crust-page-not-found-wrap">
					<div class="crust-not-found-logo">
						<?php if( $logo ){ ?>
							<a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><img alt="<?php echo esc_attr(get_bloginfo('name')); ?>" src="<?php echo esc_attr( $logo ); ?>" /></a>
						<?php } else {
							if ( get_bloginfo('name') != '' ) { ?>
								<h1 class="crust-404-logo"><a class="crust-site-title" href="<?php echo esc_url(home_url('/')) ?>" rel="home"><?php echo get_bloginfo('name') ?></a></h1>
							<?php  }
						} ?>
					</div>
					<div class="crust-page-not-found-top">
						<h4><?php echo esc_html__("Uh-Oh! Looks like you are lost.","crust") ?></h4>
						<p><?php echo esc_html__('The page you are looking for can not be found, you can search below.','crust') ?></p>
					</div>
					<div class="crust-not-found-form">
						<div class="crust-form-container">
							<?php get_search_form(); ?>
						</div>
						<div class="crust-srch-home-btn">
							<a class="btn primary-bg crust-dark-hover" href="<?php echo esc_url( home_url( '/' ) ); ?>">
								<span><?php echo esc_html__('Back to home page','crust'); ?></span>
							</a>
						</div>
					</div>

				</div>

			</div>
		</div>
		<div class="error-svg">
			<svg class="crust-divider crust-horizontal-flip crust-divider-style1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 217.21" preserveAspectRatio="none">
				<defs><style>.crst-div-60e44d3cab6b7{fill:url(#crst-div-404);}</style><linearGradient id="crst-div-404" y1="0.123" x2="1" y2="0.869" gradientUnits="objectBoundingBox"><stop offset="0" stop-color="#dddddd"></stop><stop offset="1" stop-color="#dddddd"></stop></linearGradient></defs>
				<g transform="translate(0 -1570.79)"><path class="crust-base-fill" d="M0-145.21,1920,72H0Z" transform="translate(0 1716)"></path>
					<path class="crst-div-60e44d3cab6b7" d="M0,0,960,109.087,0,77.48Z" transform="translate(0.164 1580.79)"></path></g>
			</svg>
		</div>
	</main>
	<?php
}

add_action('crust_site_comments','crust_site_comments_markup');
function crust_site_comments_markup(){

	if ( post_password_required() ) {
		return;
	}

	if ( have_comments() ) { ?>
		<div id="comments" class="comments">

			<h3 class="crust-inner-heading">
				<?php echo esc_html__('Comments', 'crust'); ?><span class="crust-comments-small">(<span class="primary-color"><?php comments_number( 0, 1, '%' ); ?></span>)</span>
			</h3>
			<div class="crust-inner-form-bg">

				<ul class="comment-list">
					<?php wp_list_comments(); ?>
				</ul>

				<?php if ( get_comment_pages_count() > 1 && get_option('page_comments') ) { ?>
					<nav id="comment-nav-below" class="navigation">
						<div class="nav-previous"><?php previous_comments_link(esc_html__('Older Comments', 'crust')); ?></div>
						<div class="nav-next"><?php next_comments_link(esc_html__('Newer Comments', 'crust')); ?></div>
					</nav>
				<?php }

				if ( ! comments_open() && get_comments_number() ) { ?>
					<p class="nocomments"><?php esc_html__('Comments are closed.', 'crust'); ?></p>
				<?php } ?>
			</div>

		</div>
	<?php }

	$comments_args = [
		'title_reply' => esc_html__("Leave a reply", "crust")
	];

	comment_form( $comments_args );
}

add_action('crust_site_single','crust_site_single_markup');
function crust_site_single_markup(){
	$sidebar = crust_single_settings()['bar'];
	$post_type = get_post_type();
	$class   = 'site-main crust-content-wrap';
	$class  .= ( CRUST_PORTFOLIO === $post_type ) ? ' crust-portfolio-wrap' : ' crust-single-wrap';
	$class  .= ( CRUST_PORTFOLIO === $post_type && crust_mod('portfolio_full') == '1' ) ? ' crust-full-content' : '';
	$class  .= ( $sidebar === 'none' ) ? ' crust-nobar' : ' crust-bar-' . $sidebar;
	$container_class = 'container';
	$container_class .= ( 'yes' === crust_meta('page_layout_mode') ) ? '-fluid' : '';


	while ( have_posts() ) {

		the_post();

		if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) {
			echo '<main class="' . esc_attr($class) . '">';

			do_action('crust_title_markup');

			$class = ( 'page' !== $post_type ) ? 'crust-post-wrapper' : 'crust-page-wrapper';
			$class .= ( $sidebar === 'none' || false === crust_active_sidebar() ) ? ' col-lg-12' : ' col-lg-8';

			echo '<div class="crust-content-container">';
			echo '<div class="'. esc_attr( $container_class ) .'">';
			echo '<div class="row">';
			echo '<div class="'. esc_attr( $class ) .'">';
			echo '<div class="crust-single-container">';

			do_action( 'crust_single_media' );

			if( 'post' === $post_type ){
				do_action( 'crust_post_meta_single' );
			}

			do_action( 'crust_single_content' );

			echo '</div>';

			do_action( 'crust_single_tags' );

			if( crust_mod('singl_share_on', true) == true  ) {
				do_action( 'crust_single_share' );
			}

			if( crust_mod('singl_authbox_on', true) == true  ) {
				do_action( 'crust_single_author_box' );
			}

			if( crust_mod('singl_related_on', true) == true  ) {
				do_action( 'crust_related_posts' );
			}

			if( CRUST_PORTFOLIO !== $post_type && crust_mod('singl_comments_on', true) == true ) {
				comments_template();
			}

			if( crust_mod('singl_nav_on', true) == true  ) {
				do_action( 'crust_single_prevnext' );
			}

			echo '</div>';

			do_action('crust_single_sidebar');

			echo '</div>';
			echo '</div>';
			echo '</div>';

			echo '</main>';
		}
	}
}

add_action('crust_site_search','crust_site_search_markup');
function crust_site_search_markup(){

	do_action('crust_title_markup');

	$blg_style  = crust_blog_settings()['layout'];
	$bar_layout = crust_blog_settings()['bar'];
	$class      = 'site-main crust-content-wrap';
	$class     .= ( $bar_layout !== '' ) ? ' crust-bar-' . $bar_layout : ' crust-nobar';

	$row_class  = 'crust-archive-wrapper';
	$row_class .= ( $bar_layout === 'none' || false === crust_active_sidebar() ) ? ' col-lg-12' : ' col-lg-8';
	$row_class .= ' ' . $blg_style;

	if( 'masonry' === $blg_style ){
		wp_enqueue_script('masonry');
	}

	?>
	<main class="<?php echo esc_attr( $class ); ?>">

		<div class="crust-content-container">

			<div class="container">

				<div class="row">

					<div class="<?php echo esc_attr( $row_class ); ?>">
						<div class="crust-archive-list-wrap">

							<?php if ( have_posts() ) { ?>
								<div class="crust-archive-list-wrap">
									<?php while (have_posts()) {
										the_post();
										do_action('crust_site_content');
									} ?>
								</div>
							<?php } else {

								do_action( 'crust_no_posts_markup');

							}
							?>
							<?php do_action( 'crust_paging_nav' ); ?>

						</div>

					</div>

					<?php if( $bar_layout !== 'none' ) {
						get_sidebar();
					} ?>

				</div>
			</div>

		</div>

	</main>

	<?php
}

add_action('crust_site_page','crust_site_page_markup');
function crust_site_page_markup(){
	$sidebar = '';
	if( is_active_sidebar('sidebar-1') || is_active_sidebar('sidebar-2') ) {
		if( class_exists('Crust_Core') ) {
			$sidebar = ( crust_meta( 'sidebar_position' ) === '' ) ? crust_mod( 'page_sidebar', '' ) : crust_meta( 'sidebar_position' );
		} else {
			$sidebar = 'right';
		}
	}

	$class      = 'crust-content-container';
	$class     .= ( $sidebar === 'none' ) ? ' crust-nobar' : ' crust-bar-' . $sidebar;
	$cellclass  = ( $sidebar === 'none' || false === crust_active_sidebar() ) ? ' col-lg-12' : ' col-lg-8';

	$container_class = 'container';
	$container_class .= ( 'yes' === crust_meta('page_layout_mode') ) ? '-fluid' : '';

// page title..
	do_action('crust_title_markup');
	?>

	<div class="<?php echo esc_attr( $class ); ?>">
		<div class="<?php echo esc_attr( $container_class ); ?>">
			<div class="row">
				<div class="<?php echo esc_attr( $cellclass ); ?>">
					<?php while ( have_posts() ) {
						the_post();
						the_content();
						do_action('crust_mini_pager');
					}
					if ( comments_open() ) {
						comments_template();
					} ?>
				</div>
				<?php do_action('crust_page_sidebar'); ?>
			</div>
		</div>
	</div>

	<?php
}

add_action('crust_site_archive','crust_site_archive_markup');
function crust_site_archive_markup(){
	do_action('crust_title_markup');
	global $post;

	$blg_style  = crust_blog_settings()['layout'];
	$bar_layout = crust_blog_settings()['bar'];
	$class      = 'site-main crust-content-wrap';
	$class     .= ( $bar_layout !== '' ) ? ' crust-bar-' . $bar_layout : ' crust-nobar';

	$row_class  = 'crust-archive-wrapper';
	$row_class .= ( $bar_layout === 'none' || false === crust_active_sidebar() ) ? ' col-lg-12' : ' col-lg-8';
	$row_class .= ' '.$blg_style;

	if( 'masonry' === $blg_style ){
		wp_enqueue_script('masonry');
	}

	?>

    <main class="<?php echo esc_attr( $class ); ?>">

        <div class="crust-content-container">

            <div class="container">

                <div class="row">

                    <div class="<?php echo esc_attr( $row_class ); ?>">
                        <div class="crust-archive-list-wrap">

							<?php if( have_posts() ) {
								while (have_posts()) {
									the_post();
									do_action('crust_site_content');
								}
							} else {
								do_action( 'crust_no_posts_markup' );
							} ?>

                        </div>

						<?php do_action('crust_paging_nav'); ?>

                    </div>

					<?php
					if( $bar_layout !== 'none' ) {
						get_sidebar();
					}
					?>

                </div>

            </div>
        </div>

    </main>
	<?php
}

add_action('crust_site_content','crust_site_content_markup');
function crust_site_content_markup(){
	$class      = 'crust-post-item';
	$blg_style  = crust_blog_settings()['layout'];
	$blg_cols   = crust_blog_settings()['columns'];

	$class     .= ( $blg_style == 'grid' || $blg_style == 'masonry' ) ? ' columns-' . $blg_cols : '';
	$img_size   = crust_mod('img_archive', 'large');

	?>

    <div id="post-<?php esc_attr(the_ID()); ?>" <?php post_class($class); ?>>

        <div class="crust-inner-post-wrap">
			<?php
			if ( is_sticky() ) {
				echo '<span class="crust-sticky-label">'. esc_html__('Featured', 'crust') .'</span>';
			}
                do_action('crust_post_thumbnail', $img_size);
			if ( crust_mod( 'arc_author_on', '1' ) == '1' && $blg_style !== 'list' ) {
				do_action('crust_author_by_post');
			}

			crust_get_content_format();

			?>
        </div>
    </div>
	<?php
}

add_action('crust_site_portfolio_archive','crust_site_portfolio_archive_markup');
function crust_site_portfolio_archive_markup(){
	$bar    = crust_portfolio_settings()['bar'];
	$class  = 'site-main crust-content-wrap';
	$class .= ( $bar !== '' ) ? ' crust-bar-' . $bar : ' crust-nobar';

	wp_enqueue_script('imagesloaded');
	wp_enqueue_script('isotope');

	echo '<main class="'. esc_attr( $class ) .'">';

	global $post;
	crust_page_title_template();

	$layout     = crust_portfolio_settings()['layout'];
	$columns    = crust_portfolio_settings()['columns'];
	$item       = crust_portfolio_settings()['item'];
	$port_align = ( crust_mod( 'portfolio_item_align', 'center' ) == '' ) ? '' : ' crust-portfolio-align-' . crust_mod( 'portfolio_item_align', 'center' );
	$class      = 'crust-portfolio-archive-wrapper';
	$class     .= ( $bar == 'none' ) ? ' col-lg-12' : ' col-lg-8';
	$filter_class = 'crust-filters';

	$wrp_class  = 'crust-portfolio-archive-list';
	$wrp_class .= ' crust-portfolio-columns-' . $columns . ' ' . $layout . ' ' . $item . $port_align;
	?>
    <div class="crust-content-container">

        <div class="container">

            <div class="row">

                <div class="<?php echo esc_attr( $class ); ?>">
					<?php
					$current_category = single_cat_title("", false);
					$crust_portfolio_query = new WP_Query([
						'post_type'            => 'portfolio',
						'post_status'          => 'publish',
						'posts_per_page'       => crust_mod( 'portfolio_pages_num', '10' ),
						'paged'                => get_query_var('paged') ? get_query_var('paged') : 1,
						'portfolio_categories' => $current_category,
					]);

					$args = [
						'post_type' => 'portfolio',
						'taxonomy' => 'portfolio_categories',
						'post_status' => 'publish',
					];

					$cats = get_categories($args);

					?>

                    <div class="<?php echo esc_attr( $filter_class ); ?>">
                        <ul>
                            <li class="selected"><a href="#" class="filter" data-filter="*"><span>All</span></a></li>
							<?php if( $cats ){
								foreach ( $cats as $taxonomy ) {
									if( isset( $taxonomy->slug ) && isset( $taxonomy->name ) ){
										?><li><a href="#" class="filter" data-filter=".<?php echo esc_attr( $taxonomy->slug ); ?>"><span><?php echo esc_html( $taxonomy->name ); ?></span></a></li><?php
									}
								}
							}
							?>
                        </ul>
                    </div>

                    <div class="<?php echo esc_attr( $wrp_class ); ?>" data-layout="<?php echo esc_attr( $layout ); ?>">
						<?php

						if ( $crust_portfolio_query->have_posts() ) {

							while ( $crust_portfolio_query->have_posts() ) {

								$crust_portfolio_query->the_post();
								$item_class = 'crust-portfolio-item';
								$categories = get_the_terms( get_the_ID(), 'portfolio_categories' );
								if( $categories ){
									foreach ( $categories as $category ) {
										$item_class .= ' ' . $category->slug;
									}
								}
								if( $categories ){
									?>
                                    <div id="post-<?php esc_attr( the_ID() ); ?>" class="<?php echo esc_attr( $item_class ); ?>">

										<?php crust_portfolio_image( get_the_ID() ); ?>

                                        <div class="post-content">

											<?php

											do_action('crust_portfolio_title');

											if( crust_mod( 'portfolio_item_cat_on', '1') == '1' ){
												crust_portfolio_post_cat( get_the_ID() );
											}

											if( crust_mod( 'portfolio_item_style', 'card' ) === 'hoverer'
											    && ( crust_mod( 'portfolio_item_link_on', '1') == '1' || crust_mod( 'portfolio_item_zoom_on', '1') == '1' ) ){
												crust_portfolio_box_links( get_the_ID() );
											}

											?>

                                        </div>

                                    </div>
									<?php
								}
							}
							wp_reset_postdata();

						} else {
							do_action( 'crust_no_posts_markup' );
						}
						?>

                    </div>

					<?php do_action(' crust_portfolio_paging_nav', $crust_portfolio_query ); ?>

                </div>

				<?php if( $bar !== 'none' ) { crust_portfolio_archive_sidebar(); } ?>

            </div>

        </div>

    </div>
	<?php

	echo '</main>';


}

function crust_portfolio_archive_sidebar()
{
	$bar = crust_portfolio_settings()['bar'];
	if( $bar === 'none' ) { return; }
	get_sidebar();
}

add_action('crust_site_searchform','crust_site_searchform_markup');
function crust_site_searchform_markup(){
	?>

    <form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="search-form">
        <input type="text" class="form-control" value="<?php echo esc_attr(get_search_query()); ?>" name="s" placeHolder="<?php echo esc_attr__('Enter Search Keyword ...','crust'); ?>" />
        <button type="submit" title="<?php echo esc_attr__( 'Search', 'crust'); ?>" class="crust-search-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.75 24.75"><path d="M24.54,23.49l-6-6a10.55,10.55,0,1,0-1,1l6,6a.78.78,0,0,0,.52.21.74.74,0,0,0,.53-.21A.76.76,0,0,0,24.54,23.49Zm-23-12.92a9.07,9.07,0,1,1,9.07,9.07A9.08,9.08,0,0,1,1.49,10.57Z"/></svg></button>
    </form>
	<?php
}

//functions

// Header Logo..
add_action('crust_header_logo','crust_header_logo_markup');
function crust_header_logo_markup() {

	$logo          = wp_get_attachment_url( crust_mod('crust_logo') );
	$ret_logo      = wp_get_attachment_url( crust_mod('retina_logo') );
	$stic_logo     = wp_get_attachment_url( crust_mod('sticky_logo') );
	$ret_stic_logo = wp_get_attachment_url( crust_mod('retina_sticky_logo') );
	$mob_logo      = wp_get_attachment_url( crust_mod('mobile_logo') );
	$ret_mob_logo  = wp_get_attachment_url( crust_mod('retina_mobile_logo') );

	$class         = 'crust-site-brand';
	$class        .= ( $mob_logo )      ? ' has-mobile-logo' : '';
	$retina_attr   = ( $ret_logo )      ? ' srcset="' . esc_url($ret_logo) . ' 2x"' : '';
	$stic_ret_attr = ( $ret_stic_logo ) ? ' srcset="' . esc_url($ret_stic_logo) . ' 2x"' : '';
	$mob_ret_attr  = ( $ret_mob_logo )  ? ' srcset="' . esc_url($ret_mob_logo) . ' 2x"' : '';

	$output = '<div class="'. esc_attr( $class ) .'">';

	if ( $logo || $ret_logo || $mob_logo ) {

		$output .= '<a href="' . esc_url(home_url('/')) . '" rel="home">';

            $output .= ( $stic_logo ) ? '<img class="crust-sticky-logo" alt="' . esc_attr(get_bloginfo('name')) . '" src="' . esc_url($stic_logo) . '" '.$stic_ret_attr.' />' : '';

            $output .= ( $logo ) ? '<img class="crust-main-logo" alt="' . esc_attr(get_bloginfo('name')) . '" src="' . esc_url($logo) . '" '.$retina_attr.' />' : '';

			$output .= ( $mob_logo ) ? '<img class="crust-mobile-logo" alt="' . esc_attr(get_bloginfo('name')) . '" src="' . esc_url($mob_logo) . '" '.$mob_ret_attr.' />' : '';

		$output .= '</a>';

	} else {

        $output .= ( get_bloginfo('name') != '' ) ? '<a class="crust-site-title" href="' . esc_url(home_url('/')) . '" rel="home">' . get_bloginfo('name') . '</a>' : '';

	}

	if ( get_bloginfo('description') != '' && crust_mod('show_tagline', true) == true ) {
		$output .= '<span class="crust-site-slogan">' . get_bloginfo('description') . '</span>';
	}

	$output .= '</div>';

    return $output;

}

// Header Menu..
add_action('crust_site_header_menu','crust_header_menu_markup');
function crust_header_menu_markup() {

	$global_menu = is_multisite() && '1' == crust_mod('use_global_menu', '0');
	if( $global_menu ){
		switch_to_blog(1);
	}

	$page_menu = crust_meta( 'page_menu' );
	$prim_menu = (has_nav_menu('primary')) ? 'primary' : '';
    $output = '';

	if( $page_menu ) {

		$output .= '<nav class="crust-site-navigation">';
		    $output .= '<a href="#" class="crust-responsive-btn"><i class="fi-rr-menu-burger"></i></a>';
		    $output .= '<ul>';
                wp_nav_menu([
                    'menu'           => $page_menu,
                    'container'      => '',
                    'link_before'    => '<span>',
                    'link_after'     => '</span>',
                    'items_wrap'     => '%3$s',
                    'theme_location' => 'primary',
                ]);
		    $output .= '</ul>';
		$output .= '</nav>';

	} else if ( has_nav_menu( $prim_menu ) ) {

		if ( class_exists('Crust_Custom_Menu') ) {

			Crust_Custom_Menu::crust_core_nav_menu( ['theme_location' => $prim_menu] );

		} elseif ( has_nav_menu('primary') ) {

			$output .= '<nav class="crust-site-navigation">';
			    $output .= '<a href="#" class="crust-responsive-btn"><i class="fi-rr-menu-burger"></i></a>';
			    $output .= '<ul>';
                    wp_nav_menu([
                        'container'      => '',
                        'link_before'    => '<span>',
                        'link_after'     => '</span>',
                        'items_wrap'     => '%3$s',
                        'theme_location' => 'primary',
                    ]);
			    $output .= '</ul>';
			$output .= '</nav>';

		}

	} else {
		$output .= '<nav class="crust-site-navigation"><span class="crust-menu-error">' . esc_html__('Oops!! there is no menu, Please add one.', 'crust') . '</span></nav>';
	}

	if( $global_menu ) {
		restore_current_blog();
	}

    return $output;

}

// Header Search
add_action('crust_site_header_search','crust_header_search_markup');
function crust_header_search_markup() {
	echo '<div class="crust-header-button crust-header-search">';
	    echo '<a href="#"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24.75 24.75"><path d="M24.54,23.49l-6-6a10.55,10.55,0,1,0-1,1l6,6a.78.78,0,0,0,.52.21.74.74,0,0,0,.53-.21A.76.76,0,0,0,24.54,23.49Zm-23-12.92a9.07,9.07,0,1,1,9.07,9.07A9.08,9.08,0,0,1,1.49,10.57Z"/></svg></a>';
	    do_action( 'crust_search_overlay' );
	echo '</div>';
}

// Header Cart..
add_action('crust_site_header_cart','crust_header_cart_markup');
function crust_header_cart_markup() {
	if( class_exists('Woocommerce') ){
		echo '<div class="crust-header-button crust-header-cart">';
		    crust_woo_cart();
		echo '</div>';
	}
}

// Header Dark Btn..
add_action('crust_site_header_dark','crust_header_dark_markup');
function crust_header_dark_markup() {
	echo '<div class="crust-header-button crust-header-dark">';
        echo '<label class="crust-dark-btn crust-switcher" for="crust-dark-switch">';
            echo '<input class="crust-switch-dark" type="checkbox" id="crust-dark-switch">';
            echo '<span class="crust-switch crust-round"><i class="light-icn fad fa-sun"></i><i class="dark-icn fad fa-moon-stars"></i></span>';
            echo '<span class="crust-swith-text" data-on-text="'.esc_html__('Light', 'crust').'" data-off-text="'.esc_html__('Dark', 'crust').'"></span>';
        echo '</label>';
	echo '</div>';
}

// Header template..
add_action( 'crust_header_markup', 'crust_header_template');
function crust_header_template()
{

	$show_header   = crust_option( 'show_header', '1' );
	$head_type     = crust_option( 'header_type', 'default' );
	$header_temp   = crust_option( 'header_template', '' );
	$before_head   = crust_option( 'before_header_template', '' );
	$after_head    = crust_option( 'after_header_template', '' );
	$head_module   = crust_option( 'header_module', '' );
	$head_behav    = crust_option( 'header_behavior', 'normal' );
	$head_over     = crust_option( 'header_overlab', '0' );
	$full_head     = crust_mod('header_full', '');
	$stick_offs    = crust_mod('top_sticky', 400 );
	$head_align    = crust_mod('head_align', '' );
	$show_logo     = crust_mod( 'logo_on', '1' );
	$show_menu     = crust_mod( 'menu_on', '1' );
	$show_srch     = crust_mod( 'search_on', '1' );
	$enable_dark   = crust_mod( 'dark_mode' );
	$show_dark     = crust_mod( 'dark_btn_on', '1' );
	$show_cart     = crust_mod( 'cart_on', '1' );
    $show_heart    = crust_mod( 'heart_on', '1' );
	$show_head_mod = crust_mod( 'custom_on' );
	$head_class    = crust_meta( 'header_class' );
	$full_menu     = crust_mod( 'full_menu' );
	$show_sticky_logo     = crust_mod( 'show_sticky_logo', '1' );
	$show_sticky_menu     = crust_mod( 'show_sticky_menu', '1' );
	$show_sticky_darkmod  = crust_mod( 'show_sticky_darkmod', '1' );
	$show_sticky_search   = crust_mod( 'show_sticky_search', '1' );
	$show_sticky_module   = crust_mod( 'show_sticky_module', '1' );
	$show_sticky_woo_icon = crust_mod( 'show_sticky_woo_icon', '1' );

	if( class_exists( 'Crust_core' ) ){
		$nav_animation = crust_mod( 'hover_effect', 'underline-nav' );
	} else {
		$nav_animation = 'underline-nav nav-2';
		$head_over     = crust_option( 'header_overlab', true );
		$full_head     = crust_mod('header_full', true);
	}

	$class         = 'crust-site-header';
	$class        .= ( $full_head )               ? ' crust-full-head'              : '';
	$class        .= ( $head_align )              ? ' header-align-'.$head_align    : '';
	$class        .= ( $head_behav === 'fixed' )  ? ' crust-fixed-head'             : '';
	$class        .= ( $head_type  === 'custom' ) ? ' crust-custom-header'          : '';
	$class        .= ( $head_class )              ? ' ' . $head_class               : '';
	$class        .= ( $head_over == '1' )        ? ' crust-header-overlab'         : '';
	$class        .= ( $nav_animation )           ? ' crust-' . $nav_animation      : '';
	$class        .= ( $before_head || $after_head ) ? ' crust-head-extras'         : '';
	$class        .= ( crust_mod( 'mega_full' ) == '1' ) ? ' full-mega-menu'  : '';
	$crust_sticky  = ( $head_behav === 'sticky' )   ? ' data-sticky="true"'           : '';
	$crust_sticky .= ( $head_behav === 'sticky' && $stick_offs ) ? ' data-offset="' . $stick_offs . '"' : '';

	$class .= ( !$show_sticky_logo  ) ? ' crust-hide-sticky-logo' : '';
	$class .= ( !$show_sticky_menu  ) ? ' crust-hide-sticky-menu' : '';
	$class .= ( !$show_sticky_darkmod  ) ? ' crust-hide-sticky-darkmod' : '';
	$class .= ( !$show_sticky_search  ) ? ' crust-hide-sticky-search' : '';
	$class .= ( !$show_sticky_module  ) ? ' crust-hide-sticky-module' : '';
	$class .= ( !$show_sticky_woo_icon  ) ? ' crust-hide-sticky-woo' : '';

	$row_class     = 'crust-header-row';
	$row_class    .= ( $full_menu == '1' ) ? ' crust-full-menu' : '';

    do_action('crust_wrapper_start');
	if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'header' ) ) {
		if ( '1' == $show_header && ! is_404() ) {

			echo '<header class="' . esc_attr( $class ) . '"' . $crust_sticky . '>';

                if ( class_exists( 'Crust_Core' ) && $before_head ) {
                    echo '<div class="crust-before-header">';
                        do_action('crust_site_custom_element_markup', $before_head );
                    echo '</div>';
                }

                echo '<div class="crust-header-wrap">';
                if ( 'default' == $head_type ) {

                    echo '<div class="container">';
                        echo '<div class="' . esc_attr( $row_class ) . '">';
                            if ( '1' == $show_logo ) {
                                 echo apply_filters('crust_header_logo', '');
                            }

                            if ( '1' == $show_menu || '1' == $show_cart || '1' == $show_srch ) {
                                echo '<div class="crust-head-links">';
                                    if ( '1' == $show_menu ) {
                                        echo apply_filters('crust_site_header_menu', '');
                                    }

                                    if ( '1' == $show_cart ) {
                                        do_action('crust_site_header_cart');
                                    }

                                    if ( '1' == $show_heart && function_exists( 'yith_wishlist_constructor' ) ) {
                                        do_action('crust_site_header_wishlist_button');
                                    }

                                    if ( '1' == $show_srch ) {
                                        do_action('crust_site_header_search');
                                    }

                                    if ( '1' == $show_head_mod && ! empty( $head_module ) ) {
                                        do_action('crust_site_header_module', $head_module );
                                    }

                                    if ( '1' == $enable_dark && '1' == $show_dark ) {
                                        do_action('crust_site_header_dark');
                                    }

                                echo '</div>';
                            }

                        echo '</div>';
                    echo '</div>';

                } else {

                    if ( class_exists( 'Crust_Core' ) && $header_temp != '' ) {
                        do_action('crust_site_custom_element_markup', $header_temp );
                    }

                }
                echo '</div>';

                if ( class_exists( 'Crust_Core' ) && $after_head ) {
                    echo '<div class="crust-after-header">';
                        do_action('crust_site_custom_element_markup', $after_head );
                    echo '</div>';
                }

			echo '</header>';

		}
	}
}
add_action('crust_site_header_module','crust_header_module_markup');
function crust_header_module_markup($head_module)
{
	if( class_exists( 'Crust_Core' ) ){
		do_action('crust_site_custom_element_markup', $head_module );
	}
}

// Page Title..
add_action( 'crust_title_markup', 'crust_page_title_template');
function crust_page_title_template()
{

	$show_title   = crust_option( 'show_title', '1' );
	$title_type   = crust_option( 'title_type', 'default' );
    $after_temp   = crust_option( 'after_title_template', '' );
	$before_title_temp = crust_option( 'before_title_template', '' );
	$disable_bg   = crust_option( 'disable_default_bg', '' );
	$title_temp   = crust_option('title_template', '' );
	$crumbs_on    = crust_option( 'breadcrumbs_on', '1' );
	$title_align  = crust_mod( 'title_align', 'center' );
	$title_shape  = crust_mod( 'custom_title_shape', '' );
	$title_tag    = crust_mod( 'title_tag', 'h1' );
	$subtitle_tag = crust_mod( 'subtitle_tag', 'h3' );
	$title_on     = crust_mod( 'title_on', '1' );
	$subtitle_on  = crust_mod( 'subtitle_on', '0' );
	$subtitle_txt = crust_meta( 'subtitle_text' );
	$parallax     = crust_mod( 'title_parallax' );
	$custom_shape = crust_mod( 'custom_title_shape', '' );
	$parallax_img = crust_mod( 'title_parallax_image' );
	$prim_color   = (crust_mod('primary_color', '#ff5b4a')) ? crust_mod('primary_color', '#ff5b4a') : '#ff5b4a';
	$scnd_color   = (crust_mod('secondary_color', '#2f39d3')) ? crust_mod('secondary_color', '#2f39d3') : '#2f39d3';

	$parallax_img = ( $parallax_img ) ? wp_get_attachment_url( $parallax_img ) : '';

	if ( $show_title == '1' ) {

		$title_height = ( crust_meta( 'title_height' ) === '' ) ? crust_mod( 'title_height', 'custom' ) : crust_meta( 'title_height' );
		$class        = 'crust-page-title';
		$class       .= ( $title_align ) ? ' crust-align-' . $title_align : '';
		$class       .= ( $disable_bg != '1' ) ? ' crust-title-has-bg' : '';
		$class       .= ( $title_height == 'full' ) ? ' crust-full-title' : '';
		$class       .= ( crust_meta('title_class') != '' ) ? ' ' . crust_meta( 'title_class' ) : '';
		$class       .= ( $title_shape == '1' ) ? ' crust-title-has-shape' : '';
		$class       .= ( true === $parallax ) ? ' crust-parallax-section' : '';
		$srch_txt     = ( is_search() ) ? '<span class="sm-results-text">' . esc_html__('Search Results for: ', 'crust') . '</span>' : '';

		if( ! is_404() ) {

			if( class_exists( 'Crust_Core' ) && $before_title_temp ) {
				echo '<div class="crust-before-title">';
				do_action('crust_site_custom_element_markup', $before_title_temp );
				echo '</div>';
			}

			echo '<div class="' . esc_attr( $class ) . '">';

				if( true === $parallax ){
					echo '<div class="crust-section-bg"><div class="crust-inner-bg" style="background-image: url('. esc_url($parallax_img) .')"></div></div>';
				}

				if ( 'default' === $title_type ) {

					echo '<div class="container">';

                        echo '<div class="row">';
                            echo '<div class="crust-title-wrapper">';
                                if ( $title_on == '1' ) {
                                    echo '<' . $title_tag . ' class="crust-title-heading">' . $srch_txt . crust_custom_page_title() . '</' . $title_tag . '>';
                                }
                                if( $subtitle_txt && $subtitle_on == '1' ){
                                    echo '<' . $subtitle_tag . ' class="crust-subtitle">' . $subtitle_txt . '</' . $subtitle_tag . '>';
                                }
                            echo '</div>';

                            if ( class_exists( 'Crust_Core' ) && $crumbs_on == '1' ) {
                                crust_breadcrumbs();
                            }
                        echo '</div>';

					echo '</div>';

				} else {

                    if( class_exists( 'Crust_Core' ) && $title_temp ){
                        do_action('crust_site_custom_element_markup', $title_temp );
					}

				}

				if( $custom_shape == 1 ){
					echo '<svg xmlns="http://www.w3.org/2000/svg" class="crust-title-svg" viewBox="0 0 1920 217.21" preserveAspectRatio="none">
					  <defs><style>.crust-title-gradient{fill:url(#crust-title-gradient);}</style>
					    <linearGradient id="crust-title-gradient" y1="0.123" x2="1" y2="0.869" gradientUnits="objectBoundingBox">
					      <stop offset="0" stop-color="'.esc_attr($prim_color).'"/>
					      <stop offset="1" stop-color="'.esc_attr($scnd_color).'"/>
					    </linearGradient>
					  </defs>
					  <g transform="translate(0 -1570.79)"><path class="crust-base-fill" d="M0-145.21,1920,72H0Z" transform="translate(0 1716)"/>
					  <path class="crust-title-gradient" d="M0,0,960,109.087,0,77.48Z" transform="translate(0.164 1580.79)"/></g>
					</svg>';
				}

			echo '</div>';

            if( class_exists( 'Crust_Core' ) && $after_temp ) {
                echo '<div class="crust-after-title">';
                    do_action('crust_site_custom_element_markup', $after_temp );
                echo '</div>';
            }

		}
	}
}

// Footer template..
add_action( 'crust_footer_markup', 'crust_footer_template');
function crust_footer_template()
{
	$foot_widgts = crust_option( 'footer_widgets', '' );
	$widg_type   = crust_option( 'widgets_type', 'default' );
	$widg_temp   = crust_option( 'widgets_template', '' );
	$before_widgets = crust_mod( 'before_widgets_template', '' );
	$before_subfooter = crust_mod( 'before_subfooter_template', '' );

	$sub_foot    = crust_option( 'subfooter_area', '1' );
	$fix_foot    = crust_option( 'fixed_footer', '' );
	$subf_type   = crust_option( 'subfooter_type', 'default' );
	$subf_temp   = crust_option( 'subfooter_template', '' );

	$sub_full    = crust_mod( 'subfooter_full', '' );
	$foot_full   = crust_mod( 'footer_full', '' );

	$foot_copy   = crust_mod('footer_copyrights', esc_html__('Crust © Made by winsomethemes, All rights reserved.', 'crust') );

	$class       = 'crust-site-footer';
	$class      .= ( $foot_full == '1' ) ? ' crust-full-footer' : '';
	$class      .= ( $fix_foot == '1' ) ? ' crust-fixed-footer' : '';
	$class      .= ( crust_meta('footer_class') !== '' ) ? ' ' . crust_meta('footer_class') : '';

	$widgets_bar = 'footer-widgets';
	$subfoot_bar = 'sub-footer';

	$foot_colms  = crust_mod( 'widgets_layout', '4' );
	$subfoot_colms = crust_mod( 'subfooter_layout', '2' );
	$foot_fluid  = ( $foot_full === '1' ) ? '-fluid' : '';
	$subfl       = ( $sub_full === '1' ) ? '-fluid' : '';

	$wid_class   = 'crust-footer-widgets';
	$wid_class  .= ( $widg_type == 'custom' ) ? ' crust-custom-foot-widgets' : '';
	$wid_class  .= ' crust-' . $foot_colms . '-colums';

	$sub_class   = 'crust-sub-footer';
	$sub_class  .= ( $subf_type == 'custom' ) ? ' crust-custom-foot-sub' : '';
	$sub_class  .= ' crust-' . $subfoot_colms . '-colums';

	if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) {
		if ( ! is_404() ) {

			if ( !is_404() && $fix_foot == '1' ) {
				echo '</div>';
			}
			echo '<footer class="' . esc_attr( $class ) . '">';

                if ( class_exists( 'Crust_Core' ) && $before_widgets && '1' == $foot_widgts ) {
                    echo '<div class="crust-before-top-footer">';
                        do_action('crust_site_custom_element_markup', $before_widgets );
                    echo '</div>';
                }

                if ( ( '1' == crust_mod( 'footer_widgets', '' ) && '' == crust_meta( 'footer_widgets' ) )
                     || '1' == $foot_widgts
                     || ( ! class_exists( 'Crust_Core' ) && is_active_sidebar( $widgets_bar ) ) ) {

                    echo '<div class="' . esc_attr( $wid_class ) . '">';
                    if ( $widg_type !== 'custom' ) {

                        echo '<div class="container' . $foot_fluid . '">';
                            echo '<div class="row">';
                                dynamic_sidebar( $widgets_bar );
                            echo '</div>';
                        echo '</div>';

                    } else {

                        if ( class_exists( 'Crust_Core' ) ) {
                            do_action('crust_site_custom_element_markup', $widg_temp );
                        }

                    }
                    echo '</div>';
                }

                if ( class_exists( 'Crust_Core' ) && $before_subfooter && '1' == $sub_foot ) {
                    echo '<div class="crust-before-sub-footer">';
                        do_action('crust_site_custom_element_markup', $before_subfooter );
                    echo '</div>';
                }

                if ( ( '1' == crust_mod( 'subfooter_area', '1' ) && '' == crust_meta( 'subfooter_area' ) )
                     || '1' == $sub_foot ) {
                    echo '<div class="' . esc_attr( $sub_class ) . '">';
                    if ( $subf_type !== 'custom' ) {

                        echo '<div class="container' . $subfl . '">';
                            echo '<div class="row">';
                                if ( is_active_sidebar( $subfoot_bar ) ) {
                                    dynamic_sidebar( $subfoot_bar );
                                } else {
                                    echo '<div class="crust-footer-copyrights">' . wp_kses( $foot_copy, crust_allowed_tags() ) . '</div>';
                                }
                            echo '</div>';
                        echo '</div>';

                    } else {

                        if ( class_exists( 'Crust_Core' ) && $subf_temp ) {
                            do_action('crust_site_custom_element_markup', $subf_temp );
                        }

                    }
                    echo '</div>';
                }

			echo '</footer>';

			if ( crust_mod( 'show_top', true ) ) {
				echo '<a href="#" class="crust-back-to-top"><i class="fad fa-arrow-up"></i><span>' . esc_html__( 'TOP', 'crust' ) . '</span></a>';
			}

			echo '</div>'; // main wrapper end..

		}
	}
}

// Sidebar template
add_action('crust_sidebar_markup', 'crust_sidebar_template');
function crust_sidebar_template(){
    $bar_class = 'crust-sidebar col-lg-4';
    $bar_class .= ( crust_mod( 'sticky_sidebar' ) ) ? ' crust-sticky-sidebar' : '';

    if ( is_active_sidebar('sidebar-2') ) {

        echo '<div class="'.esc_attr( $bar_class ).'">';
            dynamic_sidebar( 'sidebar-2' );
        echo '</div>';

    } elseif ( is_active_sidebar('sidebar-1') ) {

        echo '<div class="'.esc_attr( $bar_class ).'">';
            dynamic_sidebar( 'sidebar-1' );
        echo '</div>';

    }
}

// No Posts Markup..
add_action( 'crust_no_posts_markup', 'crust_no_posts_template');
function crust_no_posts_template()
{

	echo '<div class="crust-no-results-wrap crust-no-posts-found">';

	    echo '<div class="crust-no-results-icon"></div>';
		echo '<div class="crust-not-found">';
			echo '<h3 class="primary-color">'. esc_html__("Uh-Oh! ","crust") .'</h3>';
			echo '<h5>'.esc_html__( 'Sorry.. No results were found here.','crust' ) .'</h5>';
		echo '</div>';

		echo '<div class="crust-not-found-form">';

			echo '<p>'. esc_html__("The form below may help you get what you are looking for.","crust") .'</p>';
			echo '<div class="crust-form-container">';
				get_search_form();
			echo '</div>';

			echo '<div class="crust-srch-home-btn">';
				echo '<a class="btn btn-md" href="'. esc_url( home_url( '/' ) ) .'">';
					echo '<span>'. esc_html__('Go To Home Page','crust') .'</span>';
				echo '</a>';
			echo '</div>';

		echo '</div>';

	echo '</div>';

}

// Search Overlay Markup..
add_action( 'crust_search_overlay', 'crust_search_overlay_markup' );
function crust_search_overlay_markup(){
    add_action( 'wp_footer', function (){

		$shape = crust_mod( 'search_overlay_shape', true );
		$type = crust_mod( 'crust_search_type', 'creative' );

		$class = 'crust-search-box';
		$class .= ( $type == 'creative' ) ? ' crust-creative-search-box' : ' crust-default-search-box';

		$wrap_class = 'crust-search-box-wrap';
		$wrap_class .= ( $shape && $type == 'default' ) ? ' srch-with-shape' : '';

		echo '<div class=" '.esc_attr( $class ).'">';
			if( $type == 'default' ) { echo '<div class="'.esc_attr( $wrap_class ).'">'; }
			if( $type == 'creative' ) { echo '<a class="crust-close-search" href="#"><i class="fad fa-times"></i></a>'; }
				echo '<div class="crust-srch-inner">';
					if( $type == 'default' ) { echo '<a class="crust-close-search" href="#"><i class="fad fa-times"></i></a>'; }
					echo get_search_form();
					echo '<div class="crust-srch-info">'. esc_html__( 'Hit enter to search or ESC to close', 'crust' ) .'</div>';
				echo '</div>';
			if( $type == 'default' ) { echo '</div>'; }
		echo '</div>';

		if( $type == 'creative' ) {
			echo '<svg class="crust-creative-search-overlay" width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">';
				echo '<path class="crust-search-overlay-path" vector-effect="non-scaling-stroke" d="M 0 100 V 100 Q 50 100 100 100 V 100 z" />';
			echo '</svg>';
		}

    });

}

add_action( 'crust_after_footer', 'crust_footer_cart' );
function crust_footer_cart(){
	if( crust_mod('cart_on', '1') == '1' && class_exists('Woocommerce') ){

		$shape = crust_mod( 'cart_overlay_shape', true );
		$class = 'crust-cart-box';
		$class .= ( $shape ) ? ' cart-with-shape' : '';

		echo '<div class="'.esc_attr($class).'">';
			do_action( 'crust_render_cart_box' );
		echo '</div>';

	}
}

add_action( 'crust_page_sidebar', 'crust_page_sidebar_markup' );
function crust_page_sidebar_markup(){

	$sidebar = '';
	if( is_active_sidebar('sidebar-1') || is_active_sidebar('sidebar-2') ) {
		$sidebar = ( crust_meta('sidebar_position') === '' ) ? crust_mod( 'page_sidebar', '' ) : crust_meta('sidebar_position');
	}

	$bar = ( crust_meta('sidebar_select') !== '' ) ? crust_meta('sidebar_select') : '';

	if( $sidebar === 'none' ) { return; }
	if( $bar ){
		echo '<div class="crust-sidebar col-lg-4">';
			dynamic_sidebar($bar);
		echo  '</div>';
	} else {
		get_sidebar();
	}

}

add_action( 'crust_single_sidebar', 'crust_single_sidebar_markup' );
function crust_single_sidebar_markup(){

	$sidebar = crust_single_settings()['bar'];
	$bar     = ( crust_meta('sidebar_select') !== '' ) ? crust_meta('sidebar_select') : '';

	if( $sidebar === 'none' ) { return; }
	if( $bar ){
		echo '<div class="crust-sidebar crust-woo-sidebar col-lg-4">';
		    dynamic_sidebar($bar);
		echo  '</div>';
	} else {
		get_sidebar();
	}

}

// Render Elementor post content..
if( ! function_exists( 'crust_elementor_post_content' ) ){
    function crust_elementor_post_content()
    {
        global $post;

        if ( ! is_singular() && ( has_excerpt() || is_search() ) ) {
            the_excerpt();
        } else {
            the_content();
        }

        if ( is_singular() && 'open' === get_option( 'default_ping_status' ) && post_type_supports( $post->post_type, 'trackbacks' ) ) {
            echo '<!--';
            trackback_rdf();
            echo '-->' . "\n";
        }

    }
}
